/* Wasik Gaus
29/05/20024
 My Function List */

 
 // Thank you alert to insert a single line comment.
function tyAlert() {  
  alert("Thank you for your interest in our fitness club. We will contact you soon"); 
}

// Burpees video window to insert a comment.
function burpees() { 
  window.open("scripts/burpees.html", "_blank", "width=610, height=360");
}

// Plank video window to insert a comment.
function plank() {
   window.open("scripts/plank.html", "_blank", "width=610, height=360");
   }

   // Mountain climber video window to insert a comment.
function mtnClimber() { 
    window.open("scripts/mtn.html", "_blank", "width=610, height=360");
  }

