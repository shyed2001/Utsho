package week7;

import java.util.Scanner;

public class LectureModules {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printStars();
		addSum();
		printStars();
		int	result=multiply();
		System.out.println("The multiply result is:: "+result);
		printStars();
		int sum=sumOfThreeNum(20,54,87);
		System.out.println("Sum of three numbers:: "+sum);
		printStars();
		int value1;
		int value2;
		int value3;
		int sum1;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter value 1");
		value1=sc.nextInt();
		System.out.println("Enter value 2");
		value2=sc.nextInt();
		System.out.println("Enter value 3");
		value3=sc.nextInt();
		sum1=sumOfThreeNum(value1,value2,value3);
		System.out.println("Sum of three numbers taken from user:: "+sum1);
		printStars();

	}
	// no return value and no parameters
	public static void printStars() {
		for(int i=0;i<80;i++) {
			System.out.print("*");
		}
		System.out.println();
	}
	public static void addSum() {
		int num1;// local variables
		int num2;
		int total;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number 1");
		num1=sc.nextInt();
		System.out.println("Enter number 2");
		num2=sc.nextInt();
		total=num1+num2;
		System.out.println("The total is:: "+total);
		
	}
	
	// with return value and no parameters
	public static int multiply() {
		int num1;
		int num2;
		int multiply;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number 1");
		num1=sc.nextInt();
		System.out.println("Enter number 2");
		num2=sc.nextInt();
		multiply=num1*num2;
		return multiply;
		
	}
	
	// with return value and with parameters
	public static int sumOfThreeNum(int value1, int value2, int value3) {
		int total;
		total=value1+value2+value3;
		return total;
	}
	

}
